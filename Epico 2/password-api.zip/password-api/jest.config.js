module.exports = {
  testEnvironment: 'node',
};